# Name: Ellen Takada
# Course: CS 499
# Description: Architect Two

import csv
import time

# Define a class to hold bid information
class Employee:
    def __init__(self, id='', firstname='', lastname='', email='', job_title='', department='', salary='', hire_date='', manager_id=''):
        self.id = id
        self.firstname = firstname
        self.lastname = lastname
        self.email = email
        self.job_title = job_title
        self.department = department
        self.salary = salary
        self.hire_date = hire_date
        self.manager_id = manager_id

def display_employee(employee):
    print(f"Employee ID - {employee.id}: \n *** Name - {employee.firstname} {employee.lastname} \n *** Email -  {employee.email}"
          f"\n *** Job Title - {employee.job_title} \n *** Department - {employee.department} \n *** Salary - {employee.salary} "
          f"\n *** Hire Date - {employee.hire_date}\n *** Manager ID - {employee.manager_id} ")

def get_employee():
    id = input("Enter Id: ")
    firstname = input("Enter first name: ")
    lastname = input("Enter last name: ")
    return Employee(id, firstname, lastname)

def load_employees(csv_path):
    print(f"Loading CSV file {csv_path}")
    employees = []
    try:
        with open(csv_path, mode='r') as file:
            reader = csv.reader(file, delimiter=';')
            next(reader)  # Skip header row
            for row in reader:
                employee = Employee(
                    id=row[0],
                    firstname=row[1],
                    lastname=row[2],
                    email=row[3],
                    job_title=row[4],
                    department=row[5],
                    salary=row[6],
                    hire_date=row[7],
                    manager_id=row[8]
                )
                employees.append(employee)
    except Exception as e:
        print(e)
    return employees

def partition(employees, begin, end):
    low = begin
    high = end
    middle = begin + (end - begin) // 2
    pivot = employees[middle]
    done = False
    while not done:
        while employees[low].salary < pivot.salary:
            low += 1
        while pivot.salary < employees[high].salary:
            high -= 1
        if low >= high:
            done = True
        else:
            employees[low], employees[high] = employees[high], employees[low]
            low += 1
            high -= 1
    return high

def quick_sort(employees, begin, end):
    if begin >= end:
        return
    mid = partition(employees, begin, end)
    quick_sort(employees, begin, mid)
    quick_sort(employees, mid + 1, end)

def selection_sort(employees):
    for pos in range(len(employees) - 1):
        min_index = pos
        for j in range(pos + 1, len(employees)):
            if employees[j].salary < employees[min_index].salary:
                min_index = j
        employees[pos], employees[min_index] = employees[min_index], employees[pos]

def str_to_double(string, ch):
    return float(string.replace(ch, '').strip())

def main():
    csv_path = "cs499_employee.csv"
    employees = []
    choice = 0
    while choice != 9:
        print("Menu:")
        print("  1. Load Employees")
        print("  2. Display All Employees")
        print("  3. Selection Sort All Employees")
        print("  4. Quick Sort All Employees")
        print("  9. Exit")
        choice = int(input("Enter choice: "))

        if choice == 1:
            ticks = time.time()
            employees = load_employees(csv_path)
            print(f"{len(employees)} employees read")
            elapsed = time.time() - ticks
            print(f"time: {elapsed:.2f} seconds")

        elif choice == 2:
            for employee in employees:
                display_employee(employee)
            print()

        elif choice == 3:
            ticks = time.time()
            selection_sort(employees)
            print(f"{len(employees)} employees sorted")
            elapsed = time.time() - ticks
            print(f"time: {elapsed:.2f} seconds")

        elif choice == 4:
            ticks = time.time()
            quick_sort(employees, 0, len(employees) - 1)
            print(f"{len(employees)} employees sorted")
            elapsed = time.time() - ticks
            print(f"time: {elapsed:.2f} seconds")

    print("Goodbye.")

if __name__ == "__main__":
    main()