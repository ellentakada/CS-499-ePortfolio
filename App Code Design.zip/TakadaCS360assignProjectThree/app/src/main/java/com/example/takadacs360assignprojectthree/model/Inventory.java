package com.example.takadacs360assignprojectthree.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Inventory {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private long mId;

    @NonNull
    @ColumnInfo(name = "title")
    public String mTitle;

    @NonNull
    @ColumnInfo(name = "num")
    public String mNum;

    @ColumnInfo(name = "updated")
    private long mUpdateTime;

    public Inventory(@NonNull String title, String num) {
        mTitle = title;
        mNum = num;
        mUpdateTime = System.currentTimeMillis();
    }

    public long getId() {
        return mId;
    }

    public void setId(long id) {
        mId = id;
    }

    public String getText() {
        return mTitle;
    }

    public void setText(String title) {
        mTitle = title;
    }

    public String getNum() { return mNum; }

    public void setNum(String num) { mNum = num; }

    public long getUpdateTime() {
        return mUpdateTime;
    }

    public void setUpdateTime(long updateTime) {
        mUpdateTime = updateTime;
    }

//    private long mId;
//    private String mText;
//    private long mUpdateTime;
//
//    public Subject(@NonNull String text) {
//        mText = text;
//        mUpdateTime = System.currentTimeMillis();
//    }
//
//    public long getId() {
//        return mId;
//    }
//
//    public void setId(long id) {
//        mId = id;
//    }
//
//    public String getText() {
//        return mText;
//    }
//
//    public void setText(String subject) {
//        mText = subject;
//    }
//
//    public long getUpdateTime() {
//        return mUpdateTime;
//    }
//
//    public void setUpdateTime(long updateTime) {
//        mUpdateTime = updateTime;
//    }
}
