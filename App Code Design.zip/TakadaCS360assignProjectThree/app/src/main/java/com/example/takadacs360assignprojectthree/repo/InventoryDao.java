package com.example.takadacs360assignprojectthree.repo;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import com.example.takadacs360assignprojectthree.model.Inventory;
import java.util.List;

@Dao
public interface InventoryDao {
    @Query("SELECT * FROM Inventory WHERE id = :id")
    LiveData<Inventory> getInventory(long id);

    @Query("SELECT * FROM Inventory ORDER BY title COLLATE NOCASE")
    LiveData<List<Inventory>> getInventories();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long addInventory(Inventory inventory);

    @Update
    void updateInventory(Inventory inventory);

    @Query("UPDATE Inventory SET title = :title WHERE id = :id")
    void updateInventoryTitle(long id, String title);

    @Query("UPDATE Inventory SET num = :number WHERE id = :id")
    void updateInventoryNum(long id, String number);

    @Delete
    void deleteInventory(Inventory inventory);
}
