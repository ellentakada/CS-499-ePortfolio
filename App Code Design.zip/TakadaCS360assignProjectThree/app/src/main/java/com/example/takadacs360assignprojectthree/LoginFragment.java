package com.example.takadacs360assignprojectthree;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.takadacs360assignprojectthree.databinding.FragmentLoginBinding;
import com.example.takadacs360assignprojectthree.repo.UsersDatabase;

public class LoginFragment extends Fragment {

    private FragmentLoginBinding binding;
    private final static String TAG = "LoginActivity";
    private UsersDatabase mUserDatabase;
    private String mUserName;
    private String mPassword;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        Log.d(TAG, "Fragment created");
        binding = FragmentLoginBinding.inflate(inflater, container, false);
        Log.d(TAG, "binding created");
        mUserDatabase = new UsersDatabase(container.getContext());
        Log.d(TAG, "DB created");
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText username = (EditText)binding.usernameInput;
                mUserName = username.getText().toString();
                EditText password = (EditText)binding.passwordInput;
                mPassword = password.getText().toString();
                onSignIn(mUserName, mPassword);
            }
        });
        binding.createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText username = (EditText)binding.usernameInput;
                mUserName = username.getText().toString();
                EditText password = (EditText)binding.passwordInput;
                mPassword = password.getText().toString();
                onCreateAccount(mUserName, mPassword);
            }
        });
        binding.forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText username = (EditText)binding.usernameInput;
                mUserName = username.getText().toString();
                EditText password = (EditText)binding.passwordInput;
                mPassword = password.getText().toString();
                onForgotPassword(mUserName, mPassword);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
    private void onSignIn(String mUserName, String mPassword) {
        Log.d(TAG, "onSIGN" + mUserName + mPassword);
        if (mUserDatabase.authUser(mUserName, mPassword)) {
            Log.d(TAG, "onSIGNAUTH" + mUserName + mPassword);
            NavHostFragment.findNavController(LoginFragment.this)
                    .navigate(R.id.action_FirstFragment_to_SecondFragment);
        }
    }

    private void onForgotPassword(String mUserName, String mPassword) {
        if (mUserDatabase.authUser(mUserName, mPassword)) {
            mUserDatabase.updatePassword(mUserName, mPassword);
            onSignIn(mUserName, mPassword);
        }
    }

    private void onCreateAccount(String mUserName, String mPassword) {
        mUserDatabase.addUser(mUserName, mPassword);
        onSignIn(mUserName, mPassword);
    }
}