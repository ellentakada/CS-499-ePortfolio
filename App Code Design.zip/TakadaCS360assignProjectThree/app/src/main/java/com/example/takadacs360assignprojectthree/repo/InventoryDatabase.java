package com.example.takadacs360assignprojectthree.repo;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import com.example.takadacs360assignprojectthree.model.Inventory;

@Database(entities = {Inventory.class}, version = 1)
public abstract class InventoryDatabase extends RoomDatabase {

    public abstract InventoryDao inventoryDao();
}
