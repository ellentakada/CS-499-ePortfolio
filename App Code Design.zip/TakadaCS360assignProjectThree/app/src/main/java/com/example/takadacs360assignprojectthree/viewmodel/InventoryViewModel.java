package com.example.takadacs360assignprojectthree.viewmodel;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import com.example.takadacs360assignprojectthree.model.Inventory;
import com.example.takadacs360assignprojectthree.repo.InventoryRepository;
import java.util.List;
import androidx.lifecycle.LiveData;
public class InventoryViewModel extends AndroidViewModel {
    private final InventoryRepository mInventoryRepo;

    public InventoryViewModel(Application application) {
        super(application);
        mInventoryRepo = InventoryRepository.getInstance(application.getApplicationContext());
    }

    public LiveData<List<Inventory>> getInventories() {
        return mInventoryRepo.getInventories();
    }

    public void addInventory(Inventory inventory) {
        mInventoryRepo.addInventory(inventory);
    }

    public void updateInventory(Inventory inventory) {mInventoryRepo.updateInventory(inventory);}

    public void updateInventoryTitle(long id, String title) {mInventoryRepo.updateInventoryTitle(id, title);}

    public void updateInventoryNum(long id, String num) {mInventoryRepo.updateInventoryNum(id, num);}
    public void deleteInventory(Inventory inventory) {
        mInventoryRepo.deleteInventory(inventory);
    }

}
