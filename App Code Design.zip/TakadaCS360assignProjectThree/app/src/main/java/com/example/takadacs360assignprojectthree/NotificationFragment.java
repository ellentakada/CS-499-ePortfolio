package com.example.takadacs360assignprojectthree;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.takadacs360assignprojectthree.databinding.FragmentNotificationBinding;

public class NotificationFragment extends Fragment {

    private FragmentNotificationBinding binding;
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;

    private String mDestNumber;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentNotificationBinding.inflate(inflater, container, false);

        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ActivityCompat.requestPermissions(getActivity(), new String[]{android.Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);

        binding.acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int permissionCheck = ContextCompat.checkSelfPermission(getActivity(), android.Manifest.permission.SEND_SMS);

                if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{android.Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);
                } else {
                    EditText dest_num = binding.destNumber;
                    mDestNumber = dest_num.getText().toString();
                    if (mDestNumber.length() == 10) {
                        onActivityResult(mDestNumber);
                    }
                    else {
                        Toast.makeText(getContext(),
                                "Invalid Phone Number, please try again.", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

        binding.cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // call ask permission function
                NavHostFragment.findNavController(NotificationFragment.this)
                        .navigate(R.id.action_notificationFragment_to_SecondFragment);
            }
        });

    }

    public void onActivityResult(String destNumber) {
            // send alerts to users as SMS message
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(destNumber, null, "Your Inventory Item Reached Zero.", null, null);
            Toast.makeText(getContext(), "SMS sent.",
                    Toast.LENGTH_LONG).show();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}