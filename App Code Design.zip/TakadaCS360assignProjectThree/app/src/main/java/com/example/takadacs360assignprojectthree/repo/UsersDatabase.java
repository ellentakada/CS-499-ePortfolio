package com.example.takadacs360assignprojectthree.repo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class UsersDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 2;

    private static final String TAG = "User_DB";

    public UsersDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USERNAME + " text, " +
                UserTable.COL_PASSWORD + " text)");
        Log.d(TAG, "table created");
//        addUser("test", "test");
    }

    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    public void addUser(String userName, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, userName);
        values.put(UserTable.COL_PASSWORD, password);

        long userId = db.insert(UserTable.TABLE, null, values);
        Log.d(TAG, userId + userName + password + "added");
    }

    public boolean authUser(String userName, String password) {
        Log.d(TAG, "authUser");
        SQLiteDatabase db = this.getWritableDatabase();

        String sql = "select password from " + UserTable.TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { userName});
        Log.d(TAG, "cursor" + cursor.getColumnCount());
        if (cursor.moveToFirst()) {
            Log.d(TAG, "cursor" + cursor.getColumnCount());
            do {
                String current_password = cursor.getString(0);
                Log.d(TAG, userName + password + " pw found");
                if (current_password.equals(password)) {
                    Log.d(TAG, userName + password + "authed");
                    return true;
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return false;
    }

    public boolean updatePassword(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_PASSWORD, password);

        int rowsUpdated = db.update(UserTable.TABLE, values, "username = ?",
                new String[] { username });
        return rowsUpdated > 0;
    }

    public boolean deleteUser(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(UserTable.TABLE, UserTable.COL_ID + " = ?",
                new String[]{Long.toString(id)});
        return rowsDeleted > 0;
    }
}
