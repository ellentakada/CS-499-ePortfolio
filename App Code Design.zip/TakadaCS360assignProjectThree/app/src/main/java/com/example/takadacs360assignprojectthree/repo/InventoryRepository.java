package com.example.takadacs360assignprojectthree.repo;

import android.content.Context;
import androidx.lifecycle.LiveData;
import androidx.room.Room;
import com.example.takadacs360assignprojectthree.model.Inventory;
import java.util.List;
public class InventoryRepository {
    private static InventoryRepository mInventoryRepo;
    private final InventoryDao mInventoryDao;

    public static InventoryRepository getInstance(Context context) {
        if (mInventoryRepo == null) {
            mInventoryRepo = new InventoryRepository(context);
        }
        return mInventoryRepo;
    }

    private InventoryRepository(Context context) {
        InventoryDatabase database = Room.databaseBuilder(context, InventoryDatabase.class, "inventory.db").allowMainThreadQueries().build();

        mInventoryDao = database.inventoryDao();
    }

    public void addInventory(Inventory inventory) {
        long inventoryId = mInventoryDao.addInventory(inventory);
        inventory.setId(inventoryId);
    }

    public void updateInventory(Inventory inventory) {
        mInventoryDao.updateInventory(inventory);
    }

    public void updateInventoryTitle(long inventoryId, String title) {
        mInventoryDao.updateInventoryTitle(inventoryId, title);
    }

    public void updateInventoryNum(long inventoryId, String number) {
        mInventoryDao.updateInventoryNum(inventoryId, number);
    }


    public void deleteInventory(Inventory inventory) {
        mInventoryDao.deleteInventory(inventory);
    }

    public LiveData<Inventory> getInventory(long inventoryId) {
        return mInventoryDao.getInventory(inventoryId);
    }

    public LiveData<List<Inventory>> getInventories() {
        return mInventoryDao.getInventories();
    }


}
