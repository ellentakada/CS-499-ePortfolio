package com.example.takadacs360assignprojectthree;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.takadacs360assignprojectthree.databinding.FragmentInventoryBinding;
import com.example.takadacs360assignprojectthree.model.Inventory;
import com.example.takadacs360assignprojectthree.repo.InventoryDao;
import com.example.takadacs360assignprojectthree.viewmodel.InventoryViewModel;
import java.util.ArrayList;
import java.util.List;
import androidx.lifecycle.ViewModelProvider;

public class InventoryFragment extends Fragment
         {
    private FragmentInventoryBinding binding;
    public static final String ARG_BAND_ID = "InvId";
    public static final String TAG = "InvFrag";
    private String mNewInventory;
    private String mNewInventoryNum;
    private ImageButton mNotification;
    private ImageButton mAddButton;
    private InventoryAdapter mInventoryAdapter;
    private RecyclerView mRecyclerView;
    private InventoryViewModel mInventoryViewModel;
    private Inventory mInventory;
    private Boolean mLoadInventoryList = true;

    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        super.onCreate(savedInstanceState);

        View rootView = inflater.inflate(R.layout.fragment_inventory, container, false);

        mInventoryViewModel = new ViewModelProvider(this).get(InventoryViewModel.class);

        binding = FragmentInventoryBinding.inflate(inflater, container, false);

        // notification icon setup
        mNotification = rootView.findViewById(R.id.notification);
        mNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // jump to notification setting
                NavHostFragment.findNavController(InventoryFragment.this)
                        .navigate(R.id.action_SecondFragment_to_notificationFragment);
            }
        });

        // add icon setup
        mAddButton = rootView.findViewById(R.id.add_button);
        // listening to add icon
        mAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // add a new inventory item
                EditText new_inventory = (EditText)rootView.findViewById(R.id.new_inventory);
                mNewInventory = new_inventory.getText().toString();
                EditText new_inventory_num = (EditText)rootView.findViewById(R.id.new_inventory_num);
                mNewInventoryNum = new_inventory_num.getText().toString();
                onInventoryEntered(mNewInventory, mNewInventoryNum);
            }
        });

        // Create 2 grid layout columns
        mRecyclerView = rootView.findViewById(R.id.inv_list);
        Log.d(TAG, "grid ");

        RecyclerView.LayoutManager gridLayoutManager =
                new GridLayoutManager(getContext(), 1);

        // set adapter with empty array list
        List<Inventory> InventoryList2 = new ArrayList<Inventory>();
        mInventoryAdapter = new InventoryAdapter(InventoryList2);
        mRecyclerView.setAdapter(mInventoryAdapter);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        // Show the inventories
        mInventoryViewModel.getInventories().observe(getViewLifecycleOwner(), inventories -> {
            updateUI(inventories);
        });
        return rootView;
    }

    // update UI function
    private void updateUI(List<Inventory> InventoryList) {
        Log.d(TAG, "inventory list: " + InventoryList.toString());
        // refresh the inventory list with a new inventory
        mInventoryAdapter = new InventoryAdapter(InventoryList);
        mRecyclerView.setAdapter(mInventoryAdapter);
    }

    // add a new inventory item to the list
    public void onInventoryEntered(String InventoryText, String InventoryNum) {
        if (InventoryText.length() > 0) {
            Inventory inventory = new Inventory(InventoryText, InventoryNum);
            mLoadInventoryList = false;
            mInventoryViewModel.addInventory(inventory);
            mInventoryAdapter.addInventory(inventory);
            Toast.makeText(getContext(),
                    "New Item is Successfully Added.", Toast.LENGTH_LONG).show();
        }
        // if no entry
        else {
            Toast.makeText(getContext(),
                    "Missing an Entry, Please Try Again.", Toast.LENGTH_LONG).show();
        }
    }

    private class InventoryHolder extends RecyclerView.ViewHolder {

        private Inventory mInventory;
        private EditText mInventoryText;
        private EditText mInventoryQuantity;
        private ImageButton mInventoryTrash;

        // define recycler view elements
        public InventoryHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.fragment_layout, parent, false));
            mInventoryText = itemView.findViewById(R.id.inventory_list_title);
            mInventoryQuantity = itemView.findViewById(R.id.inventory_list_quantity);
            mInventoryTrash = itemView.findViewById(R.id.inventory_list_trashbin);
        }

        // bind elements
        public void bind(Inventory inventory) {
            mInventory = inventory;
            mInventoryText.setText(inventory.getText());
            mInventoryQuantity.setText(inventory.getNum());
            mInventoryTrash.setImageResource(R.drawable.trash);

            // listening to enter key for inventory name
            mInventoryText.setOnKeyListener(new View.OnKeyListener() {
                @Override
                public boolean onKey(View v, int keyCode, KeyEvent event) {
                    // if enter is pressed, update the inventory name
                    if (keyCode == KeyEvent.KEYCODE_ENTER) {
                        Log.d(TAG,"enter text triggered");
                        String newTitle = mInventoryText.getText().toString();
                        mInventoryViewModel.updateInventoryTitle(mInventory.getId(), newTitle);
                        mInventoryAdapter.updateInventory(mInventory);
                        Toast.makeText(getContext(),
                                "Inventory Item Updated.", Toast.LENGTH_LONG).show();
                    }
                    return false;
                }

            });

            // listening to enter key for inventory name
            mInventoryQuantity.setOnKeyListener(new View.OnKeyListener() {
                @Override
                public boolean onKey(View v, int keyCode, KeyEvent event) {
                    // if enter is pressed, update the inventory quantity
                    if (keyCode == KeyEvent.KEYCODE_ENTER) {
                        String newQuantity = mInventoryQuantity.getText().toString();
                        mInventoryViewModel.updateInventoryNum(mInventory.getId(), newQuantity);
                        mInventoryAdapter.updateInventory(mInventory);
                        Toast.makeText(getContext(),
                                "Inventory Item Updated.", Toast.LENGTH_LONG).show();
                    }
                    return false;
                }

            });
            mInventoryTrash.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mInventoryViewModel.deleteInventory(mInventory);
                    mInventoryAdapter.removeInventory(mInventory);
                    Toast.makeText(getContext(),
                            "Inventory Item Deleted.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private class InventoryAdapter extends RecyclerView.Adapter<InventoryHolder> {

        private final List<Inventory> mInventoryList;

        public InventoryAdapter(List<Inventory> inventories) {
            mInventoryList = inventories;
        }

        @NonNull
        @Override
        public InventoryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new InventoryHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(InventoryHolder holder, int position){
            Inventory inventory = mInventoryList.get(position);
            holder.bind(inventory);
            holder.itemView.setTag(inventory.getId());
        }

        // add inventory function
        public void addInventory(Inventory inventory) {

            // Add the new subject at the beginning of the list
            mInventoryList.add(0, inventory);

            // Notify the adapter that item was added to the beginning of the list
            notifyItemInserted(0);

            // Scroll to the top
            mRecyclerView.scrollToPosition(0);
        }

        // update inventory function
        public void updateInventory(Inventory inventory) {
            int index = mInventoryList.indexOf(inventory);
            notifyItemChanged(index);
        }

        // remove inventory function
        public void removeInventory(Inventory inventory) {
            int index = mInventoryList.indexOf(inventory);
            if (index >= 0) {
                mInventoryList.remove(inventory);
                notifyItemRemoved(index);
            }
        }

        @Override
        public int getItemCount() {
            return mInventoryList.size();
        }
    }
}
