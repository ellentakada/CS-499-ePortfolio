package com.example.takadacs360assignprojectthree;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.takadacs360assignprojectthree.databinding.FragmentPasswordresetBinding;
import com.example.takadacs360assignprojectthree.repo.UsersDatabase;

public class PasswordResetFragment extends Fragment {
    private FragmentPasswordresetBinding binding;
    private final static String TAG = "PWResetActivity";
    private UsersDatabase mUserDatabase;
    private String mUserName;
    private String mPassword;
    private String mNewPassword;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        Log.d(TAG, "Fragment created");
        binding = FragmentPasswordresetBinding.inflate(inflater, container, false);
        Log.d(TAG, "binding created");
        mUserDatabase = new UsersDatabase(container.getContext());
        Log.d(TAG, "DB created");
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // listening to confirm button
        binding.confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText username = (EditText)binding.usernameInput;
                mUserName = username.getText().toString();
                EditText password = (EditText)binding.passwordInput;
                mPassword = password.getText().toString();
                EditText newPassword = (EditText)binding.newPasswordInput;
                mNewPassword = newPassword.getText().toString();
                // call onReset with username and password
                onReset(mUserName, mPassword, mNewPassword);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    // password reset function
    private void onReset(String mUserName, String mPassword, String mNewPassword) {
        Log.d(TAG, "onSIGN" + mUserName + mPassword);
        // successfully authenticated
        if (mUserDatabase.authUser(mUserName, mPassword)) {
            // update password
            mUserDatabase.updatePassword(mUserName, mNewPassword);
            Log.d(TAG, "onReset, updating password for: " + mUserName);
            Toast.makeText(getContext(),
                    "Password is Successfully Updated.", Toast.LENGTH_LONG).show();
            // sign into inventory list
            NavHostFragment.findNavController(PasswordResetFragment.this)
                    .navigate(R.id.action_PasswordResetFragment_to_InventoryFragment);
        }
        else {
            // incorrect old password
            Toast.makeText(getContext(),
                    "Incorrect Password, Please Try Again.", Toast.LENGTH_LONG).show();
        }
    }
}
