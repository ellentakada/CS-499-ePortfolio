package com.example.takadacs360assignprojectthree;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.takadacs360assignprojectthree.databinding.FragmentAccountBinding;
import com.example.takadacs360assignprojectthree.databinding.FragmentPasswordresetBinding;
import com.example.takadacs360assignprojectthree.repo.UsersDatabase;

public class AccountFragment extends Fragment {
    private FragmentAccountBinding binding;
    private final static String TAG = "PWResetActivity";
    private UsersDatabase mUserDatabase;
    private String mUserName;
    private String mPassword;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        Log.d(TAG, "Fragment created");
        binding = FragmentAccountBinding.inflate(inflater, container, false);
        Log.d(TAG, "binding created");
        mUserDatabase = new UsersDatabase(container.getContext());
        Log.d(TAG, "DB created");
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // listening to create button
        binding.create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText username = (EditText)binding.usernameInput;
                mUserName = username.getText().toString();
                EditText password = (EditText)binding.passwordInput;
                mPassword = password.getText().toString();
                // call onReset with username and password
                onCreateAccount(mUserName, mPassword);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    // create account function
    private void onCreateAccount(String mUserName, String mPassword) {
        Log.d(TAG, "onCreateAccount, creating an account for: " + mUserName);
        // create an account
        mUserDatabase.addUser(mUserName, mPassword);
        Toast.makeText(getContext(),
                "Account is Successfully Created.", Toast.LENGTH_LONG).show();
        // sign into inventory list
        NavHostFragment.findNavController(AccountFragment.this)
                .navigate(R.id.action_AccountFragment_to_InventoryFragment);
    }
}
